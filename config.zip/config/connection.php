<?php





// database info
$host = "sql213.infinityfree.com";
$db_name = "if0_41973522_blog_tangervibe";
$username = "if0_41973522";
$password = "3or8BntWwHW7";

try {
    // connect database
    $conn = new PDO(
        "mysql:host=$host;dbname=$db_name;charset=utf8mb4",
        $username,
        $password
    );

    // show errors
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // connection error

    echo "Connection Error: " . $e->getMessage();
}


