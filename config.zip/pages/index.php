<?php
session_start();
 require '../config/connection.php';

 // get latest posts
 $stmt = $conn->prepare("
        select posts.*, categories.cat_name, users.user_name
        from posts
        inner join categories on posts.category_id = categories.id_category
        left join users on posts.user_id = users.id_user
        where posts.status = 'published'
        order by posts.created_at desc
        limit 3
 ");

 $stmt->execute();

 $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);



?>









<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tangier Vibes - Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
    
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/footer.css">
</head>
<body>


<?php require '../includes/header.php'; ?>

        <!-- hero -->
        <section class="hero_section">
            <img src="../assets/images/home.jpg"  alt="Tanger Vibes" loading="lazy">
            <div class="hero_shadow"></div>


            <div class="hero_content">
               
                <p class="hero_label">WELCOME TO YOUR GATEWAY TO AFRICA</p>
                <h1 class="hero_title">Experience the Magic<br> of <span class="hero_highlight">Tangier</span></h1>

                <p class="hero_desc">Discover hidden beaches, legendary cafes, exquisite<br>restaurants, and historic landmarks in the Pearl of the North.</p>
                
                <div class="hero_btns">

                    <a href="explor.php" class="btn_explor">
                        Start Exploring
                    </a>

                </div>
            </div>
        </section>


        <!-- latest posts -->
        <section class="latest_section">
            <div class="section_header">
                <h2 class="title">Latest Places</h2>
                <p class="description">The newest additions to TangierVibes</p>
            </div>



            <div class="grid_place">
                    <?php if (!empty($posts)): ?>
                        <?php foreach ($posts as $post): ?>

                            <!-- post card -->
                            <a href="detail.php?id=<?= $post['id_post']; ?>" class="card_place">

                                <img     src="<?= htmlspecialchars($post['image']); ?>"     alt="<?= htmlspecialchars($post['title']); ?>"     loading="lazy">

                                <div class="card_content">

                                    <span class="category">
                                        <i class="fa-solid fa-layer-group"></i>
                                        <?= htmlspecialchars($post['cat_name']); ?>
                                    </span>

                                    <h3 class="title">
                                        <?= htmlspecialchars($post['title']); ?>
                                    </h3>

                                    <p class="location">
                                        <i class="fa-solid fa-user"></i>
                                        By <?= htmlspecialchars($post['user_name'] ?? 'Admin'); ?>
                                    </p>

                                    <p class="location">
                                        <i class="fa-solid fa-calendar-days"></i>
                                        <?= date('M d, Y', strtotime($post['created_at'])); ?>
                                    </p>

                                    <span class="btn">
                                        Read More <i class="fa-solid fa-arrow-right"></i>
                                    </span>

                                </div>


                            </a>

                        <?php endforeach; ?>
                    <?php else: ?>

                        <p class="description">No published places yet.</p>

                    <?php endif; ?>
                </div>

            


                <div class="footer_section">

                    <a href="explor.php" class="view_explor">

                        View All Places <i class="fa-solid fa-arrow-right"></i>

                    </a>

                </div>

        </section>


<?php require '../includes/footer.php' ?>
    <script src="../assets/js/main.js"></script>
</body>
</html>
