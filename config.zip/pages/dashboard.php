<?php
session_start();
require '../config/connection.php';


// check login
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit();
}

$id_user = $_SESSION['id_user'];
$user_name = $_SESSION['user_name'];
$role = $_SESSION['role'];

// get posts
if ($role === 'admin') {
    $stmt = $conn->prepare("
        select posts.*, categories.cat_name, users.user_name
        from posts
        inner join categories on posts.category_id = categories.id_category
        left join users on posts.user_id = users.id_user
        order by posts.created_at desc
    ");
    $stmt->execute();
} else {
    $stmt = $conn->prepare("
        select posts.*, categories.cat_name
        from posts
        inner join categories on posts.category_id = categories.id_category
        where posts.user_id = ?
        order by posts.created_at desc
    ");
    $stmt->execute([$id_user]);
}

$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// count posts
$total_posts = count($posts);
$pending_posts = 0;
$published_posts = 0;
$rejected_posts = 0;
$draft_posts = 0;

foreach ($posts as $post) {
    if ($post['status'] === 'pending') $pending_posts++;
    if ($post['status'] === 'published') $published_posts++;
    if ($post['status'] === 'rejected') $rejected_posts++;
    if ($post['status'] === 'draft') $draft_posts++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Tangier Vibes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>

<?php require '../includes/header.php'; ?>

<main class="dashboard_page">
    <!-- header -->
    <section class="dashboard_head">
        <div>
            <span class="dashboard_label">
                <i class="fa-solid fa-gauge"></i>
                Dashboard
            </span>
            <h1>Welcome, <?= htmlspecialchars($user_name); ?></h1>
            <p>Manage your posts and track their publishing status.</p>
        </div>

        <a href="add_post.php" class="add_post_btn">
            <i class="fa-solid fa-plus"></i>
            Add Post
        </a>
    </section>

    <!-- stats -->
    <section class="stats_grid">
        <div class="stat_card">
            <span>Total Posts</span>
            <strong><?= $total_posts; ?></strong>
        </div>

        <div class="stat_card">
            <span>Published</span>
            <strong><?= $published_posts; ?></strong>
        </div>

        <div class="stat_card">
            <span>Pending</span>
            <strong><?= $pending_posts; ?></strong>
        </div>

        <div class="stat_card">
            <span>Draft</span>
            <strong><?= $draft_posts; ?></strong>
        </div>

        <div class="stat_card">
            <span>Rejected</span>
            <strong><?= $rejected_posts; ?></strong>
        </div>
    </section>

    <!-- posts table -->
    <section class="posts_box">
        <div class="box_head">
            <h2>Posts</h2>
        </div>

        <p class="scroll_table">
            <i class="fa-solid fa-arrow-left-long"></i>
            Scroll table
            <i class="fa-solid fa-arrow-right-long"></i>
        </p>


        <?php if (!empty($posts)): ?>
            <div class="table_wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Category</th>

                            <?php if ($role === 'admin'): ?>
                                <th>Author</th>
                            <?php endif; ?>

                            <th>Status</th>
                            <th>Date <span class="date_format">(d/m/y)</span></th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($posts as $post): ?>
                            <tr>
                                <td>
                                    <span class="title_cell">
                                        <?= htmlspecialchars($post['title']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?= htmlspecialchars($post['cat_name']); ?>
                                </td>

                                <?php if ($role === 'admin'): ?>
                                    <td>
                                        <?= htmlspecialchars($post['user_name'] ?? 'admin'); ?>
                                    </td>
                                <?php endif; ?>

                                <td>
                                    <span class="status <?= htmlspecialchars($post['status']); ?>">
                                        <?= htmlspecialchars($post['status']); ?>
                                    </span>
                                </td>

                                <td class="date_cell"><?= date('d/m/y', strtotime($post['created_at'])); ?></td>

                                <td>
                                    <div class="table_actions">
                                        <!-- view -->
                                        <a href="#view_post_<?= $post['id_post']; ?>" class="action_btn view">
                                            <i class="fa-solid fa-eye"></i>
                                            <span>View</span>
                                        </a>

                                        <?php if ($post['user_id'] == $id_user): ?>
                                            <!-- edit -->
                                            <a href="edete.php?id=<?= $post['id_post']; ?>" class="action_btn edit">
                                                <i class="fa-solid fa-pen"></i>
                                                <span>Edit</span>
                                            </a>
                                        <?php endif; ?>

                                        <?php if ($role === 'admin' && $post['user_id'] != $id_user): ?>
                                            <?php if ($post['status'] !== 'published'): ?>
                                                <!-- approve -->
                                                <a href="../includes/actions.php?action=approve&id=<?= $post['id_post']; ?>" class="action_btn approve">
                                                    <i class="fa-solid fa-check"></i>
                                                    <span>Approve</span>
                                                </a>
                                            <?php endif; ?>

                                            <?php if ($post['status'] !== 'rejected'): ?>
                                                <!-- reject -->
                                                <a href="reject.php?id=<?= $post['id_post']; ?>" class="action_btn reject">
                                                    <i class="fa-solid fa-xmark"></i>
                                                    <span>Reject</span>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if ($role !== 'admin' && $post['status'] === 'rejected' && !empty($post['rejection_reason'])): ?>
                                            <!-- reason -->
                                            <a href="#reject_reason_<?= $post['id_post']; ?>" class="action_btn reason">
                                                <i class="fa-solid fa-circle-info"></i>
                                                <span>Reason</span>
                                            </a>
                                        <?php endif; ?>

                                        <!-- delete -->
                                        <a href="delet.php?id=<?= $post['id_post']; ?>" class="action_btn delete"  onclick="return confirm('Are you sure you want to delete this post?');">
                                            <i class="fa-solid fa-trash"></i>
                                            <span>Delete</span>
                                        </a>
                                    </div>


                                    <!-- view modal -->
                                    <div id="view_post_<?= $post['id_post']; ?>" class="view_modal">
                                        <div class="view_card">

                                            <div class="view_head">
                                                <h3>Post details</h3>

                                                <a href="#" class="view_close">
                                                    <i class="fa-solid fa-xmark"></i>
                                                </a>
                                            </div>

                                            <?php if (!empty($post['image'])): ?>
                                                <img src="<?= htmlspecialchars($post['image']); ?>" alt="<?= htmlspecialchars($post['title']); ?>">
                                            <?php endif; ?>

                                            <div class="view_info">
                                                <p>
                                                    <strong>Title</strong>
                                                    <?= htmlspecialchars($post['title']); ?>
                                                </p>
                                            </div>

                                            <div class="view_content">
                                                <strong>Content</strong>

                                                <p>
                                                    <?= nl2br(htmlspecialchars($post['content'])); ?>
                                                </p>
                                            </div>

                                        </div>
                                    </div>

                                    <?php if ($role !== 'admin' && $post['status'] === 'rejected' && !empty($post['rejection_reason'])): ?>
                                        <!-- reason modal -->
                                        <div id="reject_reason_<?= $post['id_post']; ?>" class="reason_modal">
                                            <div class="reason_card">
                                                <div class="reason_head">
                                                    <span>
                                                        <i class="fa-solid fa-ban"></i>
                                                        Rejection Reason
                                                    </span>

                                                    <a href="#" class="reason_close" aria-label="Close">
                                                        <i class="fa-solid fa-xmark"></i>
                                                    </a>
                                                </div>

                                                <h3><?= htmlspecialchars($post['title']); ?></h3>

                                                <p><?= nl2br(htmlspecialchars($post['rejection_reason'])); ?></p>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="empty_text">No posts yet.</p>
        <?php endif; ?>
    </section>
</main>

<script src="../assets/js/main.js"></script>
</body>
</html>
